import pandas as pd


def to_epoch_seconds(values) -> pd.Series:
    """ISO-8601 strings -> Unix epoch seconds as int64."""
    ts = pd.to_datetime(pd.Series(values), utc=True)
    return ts.astype("int64") // 10**9
