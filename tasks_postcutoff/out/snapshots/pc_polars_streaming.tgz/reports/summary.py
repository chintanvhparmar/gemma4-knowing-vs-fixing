import polars as pl


def total_by_region(lf: pl.LazyFrame) -> pl.DataFrame:
    """Total `amount` per `region`, sorted by region. Uses the streaming engine (large inputs)."""
    return (
        lf.group_by("region")
        .agg(pl.col("amount").sum().alias("total"))
        .sort("region")
        .collect(streaming=True)
    )
