# reports

Sales report helpers on top of polars LazyFrames.
