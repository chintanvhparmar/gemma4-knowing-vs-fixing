import networkx as nx


def edge_records(G: nx.Graph) -> list[dict]:
    """Edges as plain dicts (source, target, attributes) for the JSON API."""
    data = nx.node_link_data(G)
    return data["links"]


def to_payload(G: nx.Graph) -> dict:
    """Compact payload: node ids and (source, target) pairs."""
    data = nx.node_link_data(G)
    return {
        "nodes": [n["id"] for n in data["nodes"]],
        "edges": [(e["source"], e["target"]) for e in data["links"]],
    }
