from sklearn.linear_model import LogisticRegression


def make_classifier() -> LogisticRegression:
    """Multinomial (softmax) logistic regression over all topics."""
    return LogisticRegression(multi_class="multinomial", solver="lbfgs", max_iter=1000)
