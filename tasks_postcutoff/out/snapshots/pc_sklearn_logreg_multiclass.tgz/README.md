# topicmodel

Multiclass topic classifier factory.
