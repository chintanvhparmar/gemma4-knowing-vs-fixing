from django.db import models


class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)

    class Meta:
        app_label = "shop"
        constraints = [
            models.CheckConstraint(check=models.Q(price__gte=0), name="price_non_negative"),
        ]
