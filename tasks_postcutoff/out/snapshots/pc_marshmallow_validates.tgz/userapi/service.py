from .schemas import UserSchema


def parse_user(payload: dict) -> dict:
    """Validate an incoming user payload and return the loaded data."""
    return UserSchema().load(payload)
