from marshmallow import Schema, ValidationError, fields, validates


class UserSchema(Schema):
    name = fields.Str(required=True)
    age = fields.Int(required=True)

    @validates("age")
    def validate_age(self, value):
        if value < 0:
            raise ValidationError("Age must be non-negative.")
