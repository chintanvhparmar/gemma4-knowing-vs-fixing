import click


@click.group()
def cli():
    """Project tool."""


@cli.command()
def init_cmd():
    """Create the project skeleton."""
    click.echo("initialized")


@cli.command()
def build():
    """Build the project."""
    click.echo("built")
