# projtool

Usage:

    projtool init-cmd   # create the project skeleton
    projtool build      # build the project
