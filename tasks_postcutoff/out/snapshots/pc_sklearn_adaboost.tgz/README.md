# churnmodel

Model factory for the churn classifier.
