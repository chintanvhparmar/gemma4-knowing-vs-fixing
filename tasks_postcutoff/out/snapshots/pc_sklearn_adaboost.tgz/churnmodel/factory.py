from sklearn.ensemble import AdaBoostClassifier


def make_booster(n_estimators: int = 100) -> AdaBoostClassifier:
    """Boosted decision stumps (SAMME), as used in production."""
    return AdaBoostClassifier(algorithm="SAMME", n_estimators=n_estimators, random_state=0)
