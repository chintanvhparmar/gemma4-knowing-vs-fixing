import click


@click.group()
def cli():
    """Developer tool."""


@cli.command()
def build():
    """Build the project."""
    click.echo("built")
