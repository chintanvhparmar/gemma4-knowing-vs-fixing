# devtool

Running `devtool` with no arguments prints the usage text and exits successfully
(exit code 0); our CI smoke test relies on this.
