import pandas as pd


def zone_name(ts: pd.Timestamp) -> str:
    """IANA zone name of a tz-aware Timestamp, e.g. 'Europe/Berlin'."""
    return ts.tz.zone


def label(ts: pd.Timestamp) -> str:
    """Report label like '2024-06-01 12:00 (Europe/Berlin)'."""
    return f"{ts:%Y-%m-%d %H:%M} ({zone_name(ts)})"
