from marshmallow import Schema, fields


class ArticleSchema(Schema):
    id = fields.Int()
    title = fields.Str()
    can_edit = fields.Method("get_can_edit")

    def get_can_edit(self, obj):
        user = self.context.get("user")
        return user is not None and user["id"] == obj["author_id"]
