from .schemas import ArticleSchema


def serialize_article(article: dict, user: dict | None) -> dict:
    """Dump an article for the API; `can_edit` depends on the requesting user."""
    return ArticleSchema(context={"user": user}).dump(article)
