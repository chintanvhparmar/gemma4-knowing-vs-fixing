# articles

Serialises articles for the web API.
