# healthapp

Tiny Starlette service with a database connection.
