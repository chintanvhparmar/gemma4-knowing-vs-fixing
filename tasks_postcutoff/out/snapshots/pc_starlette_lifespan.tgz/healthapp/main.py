from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route

from .db import Database

db = Database()


async def health(request):
    return JSONResponse({"db": db.connected})


async def startup():
    await db.connect()


async def shutdown():
    await db.disconnect()


app = Starlette(routes=[Route("/health", health)], on_startup=[startup], on_shutdown=[shutdown])
