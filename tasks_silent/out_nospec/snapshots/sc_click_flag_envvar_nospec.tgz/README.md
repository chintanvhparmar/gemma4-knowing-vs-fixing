# shipit

`shipit deploy` deploys the current build.
