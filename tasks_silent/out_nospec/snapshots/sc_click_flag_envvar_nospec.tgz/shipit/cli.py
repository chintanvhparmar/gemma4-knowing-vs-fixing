import click


@click.group()
def cli():
    pass


@cli.command()
@click.option("--fast", "mode", is_flag=True, flag_value="fast", envvar="SHIPIT_MODE")
def deploy(mode):
    """Deploy the current build."""
    click.echo(f"deploying in {mode or 'safe'} mode")
