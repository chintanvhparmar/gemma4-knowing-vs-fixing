import numpy as np
import pandas as pd


def quality_counts(df: pd.DataFrame) -> dict:
    """Data-quality counters for the sensor feed."""
    ratio = df["reading"] / df["baseline"]
    missing = int(ratio.isna().sum())
    undefined = int(np.isnan(ratio.to_numpy(dtype="float64", na_value=0.0)).sum())
    return {"missing": missing, "undefined_ratio": undefined}
