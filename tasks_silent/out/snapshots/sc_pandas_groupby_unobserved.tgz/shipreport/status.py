import pandas as pd

REGIONS = ["north", "south", "east", "west"]
PRODUCTS = ["basic", "pro", "enterprise"]


def fully_shipped(orders: pd.DataFrame) -> dict:
    """For every (region, product) pair that HAS orders, report whether all its orders shipped.

    `orders` has columns region, product, shipped (bool). Pairs without orders are not reported.
    """
    df = orders.assign(
        region=pd.Categorical(orders["region"], categories=REGIONS),
        product=pd.Categorical(orders["product"], categories=PRODUCTS),
    )
    status = df.groupby(["region", "product"], observed=False)["shipped"].all()
    status = status.dropna()
    return {(r, p): bool(v) for (r, p), v in status.items()}
