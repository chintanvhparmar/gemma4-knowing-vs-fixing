# shipreport

Daily shipping status per region and product line.
