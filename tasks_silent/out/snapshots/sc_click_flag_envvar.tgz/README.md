# shipit

`shipit deploy` deploys in `safe` mode. `shipit deploy --fast` uses `fast` mode.
In CI the mode can also be set with the environment variable `SHIPIT_MODE`
(e.g. `SHIPIT_MODE=canary shipit deploy`).
