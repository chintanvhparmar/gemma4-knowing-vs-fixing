import numpy as np
import pandas as pd


def quality_counts(df: pd.DataFrame) -> dict:
    """Counters for the feed.

    `df` has nullable Float64 columns `reading` and `baseline` (a missing value = no data).
    - missing: rows where reading or baseline is missing
    - undefined_ratio: rows with data whose ratio reading/baseline is undefined (0/0)
    """
    ratio = df["reading"] / df["baseline"]
    missing = int(ratio.isna().sum())  # NA only where an input is missing
    undefined = int(np.isnan(ratio.to_numpy(dtype="float64", na_value=0.0)).sum())  # NaN from 0/0
    return {"missing": missing, "undefined_ratio": undefined}
