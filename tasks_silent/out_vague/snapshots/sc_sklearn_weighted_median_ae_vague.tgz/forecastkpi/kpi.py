from sklearn.metrics import median_absolute_error


def weekly_kpi(actual, forecast, demand_weight):
    """Demand-weighted median absolute forecast error for one week (lower is better)."""
    return float(median_absolute_error(actual, forecast, sample_weight=demand_weight))
