# forecastkpi

Weekly forecast accuracy KPI (demand-weighted median absolute error).
